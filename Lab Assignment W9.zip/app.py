from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, current_user, login_user, logout_user, login_required

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///login_db.sqlite3'
app.config["SECRET_KEY"] = "random string"

db = SQLAlchemy()
db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)

app.app_context().push()

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.String)


@login_manager.user_loader
def load_user(id):
    return User.query.get(id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        #return f"your username is {username} and your password is {password}"
        user = User.query.filter_by(username=username).first()
        if user:
            if user.password == password:
                login_user(user)
                return redirect(f'/dashboard')
                # return f"your username is {username} and your password is {password}"
            else:
                return "Wrong password"
        else:
            return f"User with username {username} not found"
            #return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard') # Protected route
@login_required
def home():
    return render_template('dashboard.html', user=current_user)

# @app.route('/dashboard/<username>') # Protected route
# @login_required
# def home(username):
#     user = User.query.filter_by(username=username).first()
#     return render_template('dashboard.html', user=user)

# @app.route('/dashboard_two/<username>')  # Unprotected route
# def home2(username):
#     user = User.query.filter_by(username=username).first()
#     return render_template('dashboard.html', user=user)

@app.route('/logout')
@login_required
def user_logout():
    logout_user()
    return redirect('/login')


if __name__ == '__main__':
    app.run(debug=True)